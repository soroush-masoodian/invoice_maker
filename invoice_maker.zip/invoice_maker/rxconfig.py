import reflex as rx

config = rx.Config(
    app_name="invoice_maker",
)