"""Welcome to Reflex! This file outlines the steps to create a basic app."""
from rxconfig import config
import reflex as rx
from .state import State
from .components.invoice_info import invoice_info


def index():
    return rx.container(
        rx.center(
            rx.heading("Invoice Maker")
        ),
        rx.divider(),
        invoice_info(),
        margin_top="5em",
    )


# Add state and page to the app.
app = rx.App(state=State)
app.add_page(index)
app.compile()
