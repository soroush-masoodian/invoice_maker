import reflex as rx
from ..state import State


def invoice_info():
    return rx.responsive_grid(
        rx.center(
            rx.flex(
                rx.text(f"Date:", font_size="20px"),
                rx.text(f"{State.date}", font_size="20px"),
                justify_content="space-between"
            )
        ),
        rx.center(
            rx.flex(
                rx.text("Customer name: "),
                rx.input(value=State.customer_name, on_change=State.set_customer_name),
                justify_content="space-between"
            )
        ),
        rx.center(
            rx.box(
                rx.heading("Services")
            )
        ),
        rx.center(
            # service information
            rx.vstack(
                rx.flex(
                    rx.text("date: "),
                    rx.date_picker(value=State.service_date, on_change=State.set_service_date),
                ),
                rx.flex(
                    rx.text("# hours: "),
                    rx.number_input(value=State.service_n_hours, on_change=State.set_service_n_hours),
                ),
                rx.flex(
                    rx.text("Rate: "),
                    rx.number_input(value=State.service_rate, on_change=State.set_service_rate),
                ),
                rx.flex(
                    rx.text("Discount: "),
                    rx.number_input(value=State.service_discount, on_change=State.set_service_discount),
                ),
                spacing="1em"
            )
        ),
        # add service
        rx.center(
            rx.button("Add service", on_click=State.add_service)
        ),
        # list view of services in the invoice
        rx.center(
            rx.list(items=State.str_list)
        ),
        rx.center(
            rx.button("Generate Invoice", size="lg", on_click=State.generate_document)
        ),
        rx.center(
            rx.text_area(value=State.doc)
        ),
        columns=[1],
        spacing="2em",
        margin_top="2em"
    )
