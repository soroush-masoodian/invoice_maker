import reflex as rx


def service_item(service: dict):
    return rx.list_item(
        rx.text(service["Service"]),
        rx.text(service["Rate"]),
        rx.text(service["Discount"]),
        rx.text(service["Payment Due"])
    )