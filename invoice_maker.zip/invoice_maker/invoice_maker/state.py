import reflex as rx
from datetime import date


class State(rx.State):
    name = "John Doe"
    phone = "702-702-7722"
    email = "johndoe@gmail.com"
    date = date.today()
    customer_name = ""
    service_date = ""
    service_n_hours = 0.
    service_rate = 0.
    service_discount = 0.
    services_list = []
    str_list = []
    doc = ""

    def set_customer_name(self, new_customer_name):
        self.customer_name = new_customer_name

    def set_service_date(self, new_service_date):
        self.service_date = new_service_date

    def set_service_n_hours(self, new_service_n_hours):
        self.service_n_hours = new_service_n_hours

    def set_service_rate(self, new_service_rate):
        self.service_rate = new_service_rate

    def set_service_discount(self, new_service_discount):
        self.service_discount = new_service_discount

    def add_service(self):
        self.services_list.append({
            "Service": f"{self.service_date} Tutoring ({self.service_n_hours} hrs.)",
            "Rate": f"{float(self.service_rate):.2f}",
            "Discount": f"{float(self.service_discount):.2f}",
            "Payment Due": f"{float(self.service_rate) - float(self.service_discount):.2f}"
        })
        self.update_services_str_list()

    def update_services_str_list(self):
        self.str_list = []
        for s in self.services_list:
            self.str_list.append(f'{s["Service"], s["Rate"], s["Discount"], s["Payment Due"]}')

    def generate_document_meta(self):
        return "\n\\documentclass{letter}\n" + \
            "\\usepackage[utf8]{inputenc}\n" + \
            "\\usepackage[colorlinks]{hyperref}\n" + \
            "\\usepackage[left=1in,top=1in,right=1in,bottom=1in]{geometry}\n" + \
            "\\usepackage{graphicx}\n" + \
            "\\usepackage{tabularx}\n" + \
            "\\usepackage{multirow}\n" + \
            "\\usepackage{ragged2e}\n" + \
            "\\usepackage{hhline}\n" + \
            "\\usepackage{array}\n" + \
            "\\hypersetup{\n" + \
            "    urlcolor=blue\n" + \
            "}\n" + \
            "\\newcolumntype{R}[1]{>{\\raggedleft\\let\\newline\\\\arraybackslash\\hspace{0pt}}m{#1}}\n\n" + \
            "\\begin{document}\n\n" + \
            "\\thispagestyle{empty}\n\n"

    def generate_header(self):
        return "\\begin{tabularx}{\\textwidth}{l X l}\n" + \
            "    \\hspace{-8pt} \\multirow{5}{*} & \\textbf{Tutoring Services} & \\hskip12pt\\multirow{5}{*}{\\begin{tabular}" + \
            " {r}\\footnotesize\\bf INVOICE \\\\[-0.4ex] \\footnotesize\\bf DATE \\\\[-0.8ex] \\footnotesize " + \
            "\\MakeUppercase{\\today} \\\\[-0.4ex] \\footnotesize\\bf DUE \\\\[-0.8ex] " + \
            "\\footnotesize UPON RECEIPT OF SERVICES" + " \\end{tabular}}\\hspace{-6pt} \\\\\n" + \
            "    & + " + f"{self.name}" + " & \\\\ \n" + \
            "    & +1 " + f"{self.phone}" + " & \\\\\n" + \
            "    & " + f"{self.email}" + " & \\\\ \n" + \
            "\\end{tabularx}\n\n" + \
            "\\vspace{1 cm}\n\n"

    def generate_customer_info(self):
        return "BILL TO\n\n" + \
            "\\Large\\textbf{" + f"{self.customer_name}" + "}\\normalsize\n\n"

    def generate_service_rows(self):
        r = ""
        for s in self.services_list:
            r += "    \\centering " + f"{s['Service']} " + "& \\centering \\$" + f"{s['Rate']} " + "& \\centering " + \
                 f"{s['Discount']} " + "& \\$" + f"{s['Payment Due']}" + "\\\\[2.5ex]\\hline\n\n"
        return r

    def generate_balance_section(self):
        total = sum([float(x["Payment Due"]) for x in self.services_list])
        return "    & & & & \\\\\n" + \
            "    & & & \\bf" + f" Total & \\${float(total):.2f}" + "\\\\[2.5ex]\\hhline{~~~--}\n" + \
            "    & & & & \\\\\n" + \
            f"    & & & \\bf PST & \\$" + f"{float(total) * .06:.2f}" + "\\\\[2.5ex]\\hhline{~~~--}\n" + \
            "    & & & & \\\\\n" + \
            "    & & & \\bf Balance due & \\$" + f"{float(total) * 1.06:.2f}" + "\\\\[2.5ex]\\hhline{~~~==}\n"

    def generate_bill_table(self):
        return "\\begin{tabularx}{\\linewidth}{c X X X c}\n" + \
            "    \\hline\n" + \
            "    & & & &\\\\[0.25ex]\n" + \
            "\\centering{\\bf{Service}} & \\centering{\\bf{Rate}} & \\centering{\\bf{Discount}} & " + \
            "\\bf Payment due\\\\[2.5ex]\\hline" + \
            "& & & &\\\\\n" + \
            self.generate_service_rows() + \
            self.generate_balance_section()

    def generate_document_footer(self):
        return "\\end{tabularx}\n\n" + "\\vspace{1 cm}\n\n" + \
            "\\Large\\textbf{Payment instructions}\\normalsize\n\n" + \
            "\\vspace{0.1 cm}" + \
            "\\textbf{E-transfer}\\\\" + \
            f"{self.email}\n" + \
            "\\end{document}"

    def generate_document(self):
        self.doc = self.generate_document_meta()
        self.doc += self.generate_header()
        self.doc += self.generate_customer_info()
        self.doc += self.generate_bill_table()
        self.doc += self.generate_document_footer()
